'use strict';

//Importación de módulos de 3ros
const express = require('express')
const ip = require('ip');

//Importación de módulos propios
const odm = require('custom_modules/odm.js');

const dataServer = express();

dataServer.use(express.json());
dataServer.use(express.urlencoded({extended: true}));


dataServer.listen(8081, async function(){
	console.log("Servidor de gestión de datos iniciado: "+ip.address()+":8081");

	await odm.conectar();
});

//Definición de endpoints para invocación de servicios REST

//Ping
dataServer.get("/ping", async function(request,result){
	result.send("pong");
});

//Funciones para el manejo de la entidad Usuario------------------------------------------------------------

//Crear
dataServer.post("/crearusuario", async function(request,result){
	const nuevoUsuario = request.body;
	try{
		const usuarioCreado = await odm.Usuario.crear(nuevoUsuario);
		result.send(usuarioCreado);
	}catch(exCrearUsuario){
		result.status(500).send({
			message: exCrearUsuario.toString()
		});
	}
});

//Leer
dataServer.post("/getusuarioporid", async function(request,result){
	const idUsuarioLeer = request.body._id;
	try{
		const usuarioLeido = await odm.Usuario.getPorId(idUsuarioLeer);
		result.send(usuarioLeido);
	}catch(exGetUsuario){
		result.status(500).send({
			message: exGetUsuario.toString()
		});
	}
});

dataServer.post("/validarcreds", async function(request,result){
	const usuarioValidar = request.body;
	try{
		const validacion = await odm.Usuario.validarCreds(usuarioValidar);
		result.send(validacion);
	}catch(exValidarUsuario){
		result.status(500).send({
			message: exValidarUsuario.toString()
		});
	}
});

//Cambiar pwd
dataServer.post("/cambiarpwd", async function(request,result){
	const idUsuarioCambiarPwd = request.body._id;
	const nuevaPwd = request.body.pwd;
	try{
		await odm.Usuario.cambiarPwd(idUsuarioCambiarPwd, nuevaPwd);
		result.send(true);
	}catch(exCambiarPwdUsuario){
		result.status(500).send({
			message: exCambiarPwdUsuario.toString()
		});
	}
});

dataServer.post("/usuariosnombrecontiene", async function(request,result){
	const contieneA = request.body.contiene;
	try{
		const usuariosNombreContiene = await odm.Usuario.usuariosNombreContiene(contieneA);
		result.send(usuariosNombreContiene);
	}catch(exUsuariosNombreContiene){
		result.status(500).send({
			message: exUsuariosNombreContiene.toString()
		});
	}
});

//----------------------------------------------------------------------------------------------------------

//Funciones para el manejo de la entidad Publicacion--------------------------------------------------------

//Crear
dataServer.post("/crearpublicacion", async function(request,result){
	const nuevaPublicacion = request.body;
	try{
		const publicacionCreada = await odm.Publicacion.crear(nuevaPublicacion);
		result.send(publicacionCreada);
	}catch(exCrearPublicacion){
		result.status(500).send({
			message: exCrearPublicacion.toString()
		});
	}
});

//Leer
dataServer.post("/getpublicacion", async function(request,result){
	const idPublicacionLeer = request.body._id;
	try{
		const publicacionLeida = await odm.Publicacion.get(idPublicacionLeer);
		result.send(publicacionLeida);
	}catch(exGetPublicacion){
		result.status(500).send({
			message: exGetPublicacion.toString()
		});
	}
});

dataServer.post("/getpublicacionesusuario", async function(request,result){
	const idUsuarioPublicaciones = request.body._id;
	try{
		const publicacionesLeidas = await odm.Publicacion.getDeUsuario(idUsuarioPublicaciones);
		result.send(publicacionesLeidas);
	}catch(exGetPublicacionesUsuario){
		result.status(500).send({
			message: exGetPublicacionesUsuario.toString()
		});
	}
});

//Editar
dataServer.post("/editarpublicacion", async function(request,result){
	const publicacionEditada = request.body;
	try{
		await odm.Publicacion.editarPublicacion(publicacionEditada);
		result.send(true);
	}catch(exCambiarPublicacion){
		result.status(500).send({
			message: exCambiarPublicacion.toString()
		});
	}
});

//Eliminar
dataServer.post("/eliminarpublicacion", async function(request,result){
	const idPublicacionEliminar = request.body._id;
	try{
		await odm.Publicacion.eliminarPublicacion(idPublicacionEliminar);
		result.send(true);
	}catch(exEliminarPublicacion){
		result.status(500).send({
			message: exEliminarPublicacion.toString()
		});
	}
});