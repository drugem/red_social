'use strict';

//Implementación propia de ODM para la red social

//ODM
const mongoose = require('mongoose');
var odm = {};

//Conectar a bd
odm.conectar = function(){
	return new Promise(async (resolve, reject) => {
		try{
			await mongoose.connect('mongodb://localhost/red_social');
			resolve();
		}catch(exConexion){
			const errorConectar = new Error(`No ha sido posible conectar a la base de datos:\n${exConexion}`);
			reject(errorConectar);
		}
	});
}

//Desconectar de bd
odm.desconectar = function(){
	return new Promise(async (resolve, reject) => {
		try{
			await mongoose.disconnect();
			resolve();
		}catch(exDesconexion){
			const errorConectar = new Error(`No ha sido posible desconectar de la base de datos:\n${exDesconexion}`);
			reject(errorConectar);
		}
	});
}


//Manejo de entidad: Usuario---------------------------------------------------------------------------------------
odm.Usuario = {};

//Compilación (o instanciación) del modelo de Usuario
const esquemaUsuario = mongoose.Schema;
const idUsuario = esquemaUsuario.ObjectId;
const Usuario = new esquemaUsuario({
	id:     idUsuario,
	nombre: String,
	correo: String,
	pwd:    String
});
mongoose.model('Usuario', Usuario);

//CRUD de Psuario
//Para 'update', se permite solo cambiar la contraseña
//No se incluye 'delete'
odm.Usuario.crear = function(usuarioNuevo){
	return new Promise(async (resolve, reject) => {
		const usuarioCrear  = new mongoose.model("Usuario")();
		usuarioCrear.nombre = usuarioNuevo.nombre;
		usuarioCrear.correo = usuarioNuevo.correo;
		usuarioCrear.pwd    = usuarioNuevo.pwd;
		let usuarioCreado;

		try{
			usuarioCreado = await usuarioCrear.save();
			console.log(`Creación exitosa de usuario ${usuarioCreado.nombre}`);
			resolve(usuarioCreado);
		}catch(exCreacionUsuario){
			const errorCreacionUsuario = new Error(`No ha sido posible crear nuevo usuario:\n${exCreacionUsuario}`);
			reject(errorCreacionUsuario);
		}
		//------
	});
}

odm.Usuario.get = function(idBuscarUsuario){
	return new Promise(async (resolve, reject) => {
		try{
			const coincidencia = await mongoose.model("Usuario").findById(idBuscarUsuario);
			resolve(coincidencia);
		}catch(exGetUsuario){
			const errorBusqueda = new Error(`No ha sido posible buscar el usuario: ${idBuscarUsuario}: \n ${exGetUsuario}`);
			reject(errorBusqueda);
		}
		//------
	});
}

odm.Usuario.cambiarPwd = function(idUsuario, nuevaPwd){
	return new Promise(async (resolve, reject) => {
		try{
			const coincidencia = await mongoose.model("Usuario").findById(idUsuario);
			coincidencia.pwd = nuevaPwd;
			await coincidencia.save();
			resolve(true);
		}catch(exCambiarPwd){
			const errorCambiarPwd = new Error(`No ha sido posible cambiar contraseña del usuario: ${idUsuario}: \n ${exCambiarPwd}`);
			reject(errorCambiarPwd);
		}
		//------
	});
}
//-----------------------------------------------------------------------------------------------------------------

//Manejo de entidad: Publicacion---------------------------------------------------------------------------------------
odm.Publicacion = {};

//Compilación (o instanciación) del modelo de Publicacion
const esquemaPublicacion = mongoose.Schema;
const idPublicacion = esquemaPublicacion.ObjectId;
const Publicacion = new esquemaPublicacion({
	id:          idPublicacion,
	contenido:   String,
	fecha:       Date,
	publicacion: String,
	usuario:     String
});
mongoose.model('Publicacion', Publicacion);

//CRUD de Publicacion
odm.Publicacion.crear = function(publicacionNueva){
	return new Promise(async (resolve, reject) => {
		const publicacionCrear  		= new mongoose.model("Publicacion")();
		publicacionCrear.contenido 		= publicacionNueva.contenido;
		publicacionCrear.fecha 			= publicacionNueva.fecha;
		publicacionCrear.publicacion    = publicacionNueva.publicacion;
		publicacionCrear.usuario 		= publicacionNueva.usuario
		let publicacionCreada;

		try{
			publicacionCreada = await publicacionCrear.save();
			console.log(`Creación exitosa de publicación ${publicacionCreada._id}`);
			resolve(publicacionCreada);
		}catch(exCreacionPublicacion){
			const errorCreacionPublicacion = new Error(`No ha sido posible crear publicación:\n${exCreacionPublicacion}`);
			reject(errorCreacionPublicacion);
		}
		//------
	});
}

odm.Publicacion.get = function(idBuscarPublicacion){
	return new Promise(async (resolve, reject) => {
		try{
			const coincidencia = await mongoose.model("Publicacion").findById(idBuscarPublicacion);
			resolve(coincidencia);
		}catch(exGetPublicacion){
			const errorBusqueda = new Error(`No ha sido posible buscar la publicacion: ${idBuscarPublicacion}:\n${exGetPublicacion}`);
			reject(errorBusqueda);
		}
		//------
	});
}

odm.Publicacion.editarPublicacion = function(edicionPublicacion){
	return new Promise(async (resolve, reject) => {
		try{
			const coincidencia = await mongoose.model("Publicacion").findById(edicionPublicacion._id);
			for(const attr in coincidencia){
				coincidencia[attr] = edicionPublicacion[attr] || coincidencia[attr];
			}
			await coincidencia.save();
			resolve(true);
		}catch(exCambiarPublicacion){
			const errorCambiarPublicacion = new Error(`No ha sido posible editar la publicación: ${edicionPublicacion._id}:\n${exCambiarPublicacion}`);
			reject(errorCambiarPublicacion);
		}
		//------
	});
}

odm.Publicacion.eliminarPublicacion = function(idPublicacion){
	return new Promise(async (resolve, reject) => {
		try{
			await mongoose.model("Publicacion").deleteOne({_id: idPublicacion});
			resolve(true);
		}catch(exEliminarPublicacion){
			const errorEliminarPublicacion = new Error(`No ha sido posible eliminar la publicación: ${idPublicacion}:\n${exEliminarPublicacion}`);
			reject(errorEliminarPublicacion);
		}
		//------
	});
}

//-----------------------------------------------------------------------------------------------------------------

module.exports = odm;

