'use strict';

//Este script inicializa la base de datos con las 2 collecciones y un documento en cada una

const fs = require('fs');

//ODM
const mongoose = require('mongoose');

(async function initDB(){
	await mongoose.connect('mongodb://localhost/red_social');

	const correoDestino = JSON.parse(fs.readFileSync("config.json","utf8")).defaultCorreoDestino;

	//Creación del modelo 'Usuario' e inserción de un primer usuario
	const esquemaUsuario = mongoose.Schema;
	const idUsuario = esquemaUsuario.ObjectId;

	const Usuario = new esquemaUsuario({
	  id:     idUsuario,
	  nombre: String,
	  correo: String,
	  pwd:    String
	});

	const modeloUsuario = mongoose.model('Usuario', Usuario);

	const primerUsuario  = new modeloUsuario();
	primerUsuario.nombre = 'Pepito';
	primerUsuario.correo = correoDestino;
	primerUsuario.pwd    = "123";
	let idPrimerUsuario;

	try{
		idPrimerUsuario = await primerUsuario.save();
		idPrimerUsuario = idPrimerUsuario._id
	}catch(exCreacionPrimerUsuario){
		console.log("No ha sido posible inicializar el primer usuario de la red social: ");
		console.log(exCreacionPrimerUsuario);
		return;
	}
	console.log("Creación exitosa de primer usuario");

	const segundoUsuario  = new modeloUsuario();
	segundoUsuario.nombre = 'Juanita';
	segundoUsuario.correo = correoDestino;
	segundoUsuario.pwd    = "123";
	let idSegundoUsuario;

	try{
		idSegundoUsuario = await segundoUsuario.save();
		idSegundoUsuario = idSegundoUsuario._id
	}catch(exCreacionSegundoUsuario){
		console.log("No ha sido posible inicializar el segundo usuario de la red social: ");
		console.log(exCreacionSegundoUsuario);
		return;
	}
	console.log("Creación exitosa de segundo usuario");
	//------

	//Creación del modelo 'Publicacion' e inserción de una primera publicación
	const esquemaPublicacion = mongoose.Schema;
	const idPublicacion = esquemaPublicacion.ObjectId;

	const Publicacion = new esquemaPublicacion({
	  id:          idPublicacion,
	  contenido:   String,
	  fecha:       Date,
	  publicacion: String,
	  usuario:     String
	});

	const modeloPublicacion = mongoose.model('Publicacion', Publicacion);

	const primeraPublicacion       = new modeloPublicacion();
	primeraPublicacion.contenido   = 'Soy el primer usuario de la red social!';
	primeraPublicacion.fecha       = new Date();
//	primeraPublicacion.publicacion = null;
	primeraPublicacion.usuario     = idPrimerUsuario

	try{
		await primeraPublicacion.save();
	}catch(exCreacionPrimeraPublicacion){
		console.log("No ha sido posible inicializar la primera publicación de la red social: ");
		console.log(exCreacionPrimeraPublicacion);
		return;
	}
	console.log("Creación exitosa de primera publicación");
	//------

	await mongoose.disconnect();
})();