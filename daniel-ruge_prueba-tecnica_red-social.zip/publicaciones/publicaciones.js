'use strict';

//Importación de módulos de 3ros
import fetch from 'node-fetch';
import express from 'express';
import ip from 'ip';
import fs from 'fs';

//Lecutra de archivo config
const config = JSON.parse(fs.readFileSync("config.json", "utf8"));
const dataServer = config.dataserver;
//Primero, hacer un ping al servidor de datos para ver si está online. Si sí, iniciar servidor de publicaciones
try{
	const ping = await fetch(`http://${dataServer}/ping`);
	const bodyPong = await ping.text();
	if(bodyPong !== "pong"){
		console.log("No ha sido posible conectar a servidor de datos: servidor no ha retornado una respuesta esperada. Servidor de publicaciones no iniciado");
		process.exit();
	}
}catch(exPing){
	console.log(`No ha sido posible conectar al servidor de datos: servidor no ha retornado una respuesta. Servidor de publicaciones no iniciado:\n${exPing}`);
	process.exit();
}

//Iniciar servidor
const publicacionesServer = express();
publicacionesServer.use(express.json());
publicacionesServer.use(express.urlencoded({extended: true}));

publicacionesServer.listen(8083, async function(){
	console.log("Servidor de publicaciones iniciado: "+ip.address()+":8083");
});

//Definición de endpoints para invocación de servicios REST
const jsonContentType =  {'Content-Type': 'application/json'};

//Este endpoint permite crear una nueva publicación. Esto puede incluir crear una publicación para responder a otra (como si fuera un comentario o una respuesta a un comentario)
//Lo anterior sucede cuando el id de la publicación que viene en el body no es null
publicacionesServer.post("/publicar", async function(request,result){
	const nuevaPublicacion = request.body;
	try{
		const jsonCrearPublicacion = {
			contenido: 	 nuevaPublicacion.contenido,
			fecha: 		 new Date(),
			publicacion: nuevaPublicacion.publicacion,
			usuario: 	 nuevaPublicacion.usuario
		};
		const responseCrearPublicacion = await fetch(`http://${dataServer}/crearpublicacion`, {method: 'POST', body: JSON.stringify(jsonCrearPublicacion), headers: jsonContentType});
		const publicacionCreada = await responseCrearPublicacion.json();
		result.send(publicacionCreada);
	}catch(exCrearPublicacion){
		console.log(`No ha sido posible crear publicación:\n${exCrearPublicacion}`);
		result.status(500).send({
			message: exCrearPublicacion.toString()
		});
	}
});

publicacionesServer.post("/getpublicacionesusuario", async function(request,result){
	const idUsuarioPublicaciones = request.body;
	try{
		const responsePublicacionesUsuario = await fetch(`http://${dataServer}/getpublicacionesusuario`, {method: 'POST', body: JSON.stringify(idUsuarioPublicaciones), headers: jsonContentType});
		const publicacionesUsuario = await responsePublicacionesUsuario.json();
		result.send(publicacionesUsuario);
	}catch(exPublicacionesUsuario){
		console.log(`No ha sido posible obtener las publicaciones del usuario ${idUsuarioPublicaciones}:\n${exPublicacionesUsuario}`);
		result.status(500).send({
			message: exPublicacionesUsuario.toString()
		});
	}
});

publicacionesServer.post("/editar", async function(request,result){
	const publicacionEditada = request.body;
	try{
		const responseEditarPublicacion = await fetch(`http://${dataServer}/editarpublicacion`, {method: 'POST', body: JSON.stringify(publicacionEditada), headers: jsonContentType});
		await responseCrearPublicacion.json();
		result.send(true);
	}catch(exEditarPublicacion){
		console.log(`No ha sido posible editar publicación:\n${exEditarPublicacion}`);
		result.status(500).send({
			message: exEditarPublicacion.toString()
		});
	}
});

publicacionesServer.post("/eliminar", async function(request,result){
	const idPublicacionEliminar = request.body;
	try{
		const responseEliminarPublicacion = await fetch(`http://${dataServer}/eliminarpublicacion`, {method: 'POST', body: JSON.stringify(idPublicacionEliminar), headers: jsonContentType});
		await responseEliminarPublicacion.json();
		result.send(true);
	}catch(exEliminarPublicacion){
		console.log(`No ha sido posible eliminar publicación:\n${exEliminarPublicacion}`);
		result.status(500).send({
			message: exEliminarPublicacion.toString()
		});
	}
});

publicacionesServer.post("/getpublicacionporid", async function(request,result){
	try{
		const responseGetPublicacionPorId = await fetch(`http://${dataServer}/getpublicacion`, {method: 'POST', body: JSON.stringify(request.body), headers: jsonContentType});
		const publicacionPorId = await responseGetPublicacionPorId.json();
		result.send(publicacionPorId);
	}catch(exGetPublicacionPorId){
		console.log(`No ha sido posible obtener publicación ${request.body._id}:\n${exGetPublicacionPorId}`);
		result.status(500).send({
			message: exGetPublicacionPorId.toString()
		});
	}
});

//Ping
publicacionesServer.get("/ping", async function(request,result){
	result.send("pong");
});


