'use strict';

//Importación de módulos de 3ros
import fetch from 'node-fetch';
import express from 'express';
import ip from 'ip';
import fs from 'fs';

//Lecutra de archivo config
const config = JSON.parse(fs.readFileSync("config.json", "utf8"));
const dataServer = config.dataserver;

//Primero, hacer un ping al servidor de datos para ver si está online. Si sí, iniciar servidor de gestión de usuarios
try{
	const ping = await fetch(`http://${dataServer}/ping`);
	const bodyPong = await ping.text();
	if(bodyPong !== "pong"){
		console.log("No ha sido posible conectar a servidor de datos: servidor no ha retornado una respuesta esperada. Servidor de gestión de usuarios no iniciado");
		process.exit();
	}
}catch(exPing){
	console.log(`No ha sido posible conectar al servidor de datos: servidor no ha retornado una respuesta. Servidor de gestión de usuarios no iniciado:\n${exPing}`);
	process.exit();
}

//Iniciar servidor
const gestionUsuariosServer = express();
gestionUsuariosServer.use(express.json());
gestionUsuariosServer.use(express.urlencoded({extended: true}));

gestionUsuariosServer.listen(8082, async function(){
	console.log("Servidor de gestión de usuarios iniciado: "+ip.address()+":8082");
});

const jsonContentType =  {'Content-Type': 'application/json'};

//Definición de endpoints para invocación de servicios REST
gestionUsuariosServer.post("/registro", async function(request,result){
	const nuevoUsuario = request.body;
	try{
		const jsonCrearUsuario = {
			nombre: 	 nuevoUsuario.nombre,
			correo: 	 nuevoUsuario.correo,
			pwd: 		 nuevoUsuario.pwd
		};
		const responseCrearUsuario = await fetch(`http://${dataServer}/crearusuario`, {method: 'POST', body: JSON.stringify(jsonCrearUsuario), headers: jsonContentType});
		const usuarioCreado = await responseCrearPublicacion.json();
		result.send(usuarioCreado);
	}catch(exCrearUsuario){
		console.log(`No ha sido posible registrar usuario:\n${exCrearUsuario}`);
		result.status(500).send({
			message: exCrearUsuario.toString()
		});
	}
});


//Esta función valida que las credenciales en el body del request sí concuerden con las de bd
gestionUsuariosServer.post("/validarcreds", async function(request,result){
	const usuarioValidar = request.body;
	try{
		const responseValidarUsuario = await fetch(`http://${dataServer}/validarcreds`, {method: 'POST', body: JSON.stringify(usuarioValidar), headers: jsonContentType});
		const validacionUsuario = await responseValidarUsuario.json();
		result.send(validacionUsuario);
	}catch(exValidarUsuario){
		console.log(`No ha sido posible validar credenciales de usuario:\n${exValidarUsuario}`);
		result.status(500).send({
			message: exValidarUsuario.toString()
		});
	}
});

//Función para obtener todos los usuarios cuyo nombre contiene cierta cadena de texto
gestionUsuariosServer.post("/nombrecontiene", async function(request,result){
	try{
		const responseNombreContiene = await fetch(`http://${dataServer}/usuariosnombrecontiene`, {method: 'POST', body: JSON.stringify(request.body), headers: jsonContentType});
		const usuariosNombreContiene = await responseNombreContiene.json();
		result.send(usuariosNombreContiene);
	}catch(exUsuariosNombreContiene){
		console.log(`No ha sido posible encontrar usuarios cuyo nombre contenga ${request.body.contiene}:\n${exUsuariosNombreContiene}`);
		result.status(500).send({
			message: exUsuariosNombreContiene.toString()
		});
	}
});

//Función para obtener la info de un usuario según su id
gestionUsuariosServer.post("/getusuarioporid", async function(request,result){
	try{
		const responseUsuario = await fetch(`http://${dataServer}/getusuarioporid`, {method: 'POST', body: JSON.stringify(request.body), headers: jsonContentType});
		const usuarioDeId = await responseUsuario.json();
		result.send(usuarioDeId);
	}catch(exGetUsuarioPorId){
		console.log(`No ha sido posible encontrar la información del usuario ${request.body._id}:\n${exGetUsuarioPorId}`);
		result.status(500).send({
			message: exGetUsuarioPorId.toString()
		});
	}
});

//Ping
gestionUsuariosServer.get("/ping", async function(request,result){
	result.send("pong");
});
