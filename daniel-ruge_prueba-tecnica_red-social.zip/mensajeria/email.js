'use strict';

//Importación de módulos de 3ros
import fetch from 'node-fetch';
import express from 'express';
import ip from 'ip';
import fs from 'fs';
import nodemailer from 'nodemailer';

//Lecutra de archivo config
const config = JSON.parse(fs.readFileSync("config.json", "utf8"));
const dataServer = config.dataserver;
const origenCorreos = config.defaultFrom;

//Primero, hacer un ping al servidor de datos para ver si está online. Si sí, iniciar servidor de mensajería
try{
	const ping = await fetch(`http://${dataServer}/ping`);
	const bodyPong = await ping.text();
	if(bodyPong !== "pong"){
		console.log("No ha sido posible conectar a servidor de datos: servidor no ha retornado una respuesta esperada. Servidor de mensajería electrónica no iniciado");
		process.exit();
	}
}catch(exPing){
	console.log(`No ha sido posible conectar al servidor de datos: servidor no ha retornado una respuesta. Servidor de mensajería electrónica no iniciado:\n${exPing}`);
	process.exit();
}

//Ahora, levantar un pool de mensajería electrónica
let transporteEmail;
try{
	transporteEmail = nodemailer.createTransport({
		pool: true,
		service: 'gmail',
		auth: {
			user: config.emailTransportUser,
			pass: config.emailTransportPwd
		}
});
}catch(exPoolEmail){
	console.log(`No ha sido posible establecer pool para envío de correos electrónicos. Servidor de mensajería electrónica no iniciado:\n${exPoolEmail}`);
	process.exit();
}


//Iniciar servidor
const mensajeriaServer = express();
mensajeriaServer.use(express.json());
mensajeriaServer.use(express.urlencoded({extended: true}));

mensajeriaServer.listen(8084, async function(){
	console.log("Servidor de mensajería electrónica iniciado: "+ip.address()+":8084");

	//enviarCorreo(config.emailTransportUser, config.emailTransportUser, "Hola mundo", "nos vemos, mundo");
});


//Definición de endpoints para invocación de servicios REST
mensajeriaServer.post("/enviarcorreo", async function(request,result){
	try{
		const body = request.body
		await enviarCorreo(origenCorreos, body.para, body.asunto, body.cuerpo);
		result.send(true);
	}catch(exRequestEnviarCorreo){
		result.status(500).send({
			message: exRequestEnviarCorreo.toString()
		});
	}
});

//Ping
mensajeriaServer.get("/ping", async function(request,result){
	result.send("pong");
});

//Función para el envío de un correo
function enviarCorreo(de, para, asunto, cuerpo){
	return new Promise(async (resolve, reject) => {
		const mailOptions = {
			from: de,
			to: para,
			subject: asunto,
			text: cuerpo
		};

		try{
			const resultSendMail = await transporteEmail.sendMail(mailOptions);
			resolve();
		}catch(exEnviarMail){
			console.log(`No ha sido posible enviar correo: ${exEnviarMail}`);
			reject(exEnviarMail);
		}
	});
}






