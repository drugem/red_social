'use-strict';

var tiempoDesdeUltimoEvento;
var personasBuscadas = [];
$("#buscar-personas").keyup(()=>{
	tiempoDesdeUltimoEvento = new Date();
	const nombreBuscar = $("#buscar-personas").val();
	setTimeout(()=>{
		const ahora = new Date();
		if(ahora - tiempoDesdeUltimoEvento >= 1000){
			buscarPersonas(nombreBuscar);
		}
	}, 1000);
});

function buscarPersonas(nombreBuscar){
	if(nombreBuscar === ""){
		$("#personasEncontradas").html(""); 
	}
	else{

		$.ajax({
		    url: 'http://localhost:8085/encontrarpersonasnombre',
		    type: 'post',
		    data: {nombre: nombreBuscar},
		    headers: {
		        "Authorization": localStorage.getItem("red_social_token")  
		    },
		    dataType: 'json',
		    success: function (coincidencias) {
		        personasBuscadas = coincidencias;
				localStorage.setItem("personasBusqueda", JSON.stringify(personasBuscadas));
				var listaPersonas = "";
				personasBuscadas.forEach((persona, indice) =>{
					listaPersonas+=`<li><a href="verpubspersona.html?p=${indice}"><i class="fa fa-user fa-fw"></i>${persona.nombre}</a></li>`;
				});
				$("#personasEncontradas").html(listaPersonas); 
		    }
		});
	}
}