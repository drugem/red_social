const personasBuscadasStorage = JSON.parse(localStorage.getItem("personasBusqueda"));
const indicePersonaSelec = new URL(window.location.href).searchParams.get("p")
const personaPerfil = personasBuscadasStorage[indicePersonaSelec];

$("#tituloPerfil").html(`Perfil de ${personaPerfil.nombre}`);
document.title = personaPerfil.nombre;


$.ajax({
    url: 'http://localhost:8085/getpublusuario',
    type: 'post',
    data: {_id: personaPerfil._id},
    headers: {
        "Authorization": localStorage.getItem("red_social_token")  
    },
    dataType: 'json',
    success: function (publicaciones) {
        var seccionPubs = "";

		//TODO: al igual que en en el odm.js en el servidor de datos, esto sería mejor cambiarlo por una función recursiva
		//si se llega a tomar la decisión de negocio de admitir más publicaciones anidadas
		publicaciones.forEach((pubNivel1, i) => {
			seccionPubs += `
				<div class="panel-group" id="accordion${i}">
	                <div class="panel panel-default panel-primary">
	                    <div class="panel-heading">
	                        <h4 class="panel-title">
	                            <a data-toggle="collapse" data-parent="#accordion${i}" href="#collapse${i}">${pubNivel1.fecha}</a>
	                        </h4>
	                    </div>
	                    <div id="collapse${i}" class="panel-collapse collapse in">
	                        <div class="panel-body">
	                            ${pubNivel1.contenido}

	                            <div class="panel">
	                           		<div class="panel panel-default">
	                           		    <a data-toggle="collapse" data-parent="#comentar${i}" href="#comentar${i}">Comentar</a>
	                           			<div id="comentar${i}" class="panel-collapse collapse">
	                           				<div class="panel-body">
	                           					<textarea name="ta-${pubNivel1._id}" style="width:100%"></textarea>
	                           					<button class="btn btn-default confirmar-comentar" name="${pubNivel1._id}">Confirmar comentario</button>
	                           				</div>
	                           			</div>
	                            	</div>
	                           	`
		                
			pubNivel1.publicaciones.forEach((pubNivel2,j) => {
				seccionPubs += `
					<div class="panel-group" id="accordion${i}-${j}">
	                    <div class="panel panel-default panel-green">
	                        <div class="panel-heading">
	                            <h4 class="panel-title">
	                                <a data-toggle="collapse" data-parent="#accordion${i}-${j}" href="#collapse${i}-${j}">${pubNivel2.fecha}</a>
	                            </h4>
	                        </div>
	                        <div id="collapse${i}-${j}" class="panel-collapse collapse in">
	                            <div class="panel-body">
	                                ${pubNivel2.contenido}

	                                <div class="panel">
		                           		<div class="panel panel-default">
		                           		    <a data-toggle="collapse" data-parent="#responder${j}" href="#responder${j}">Responder</a>
		                           			<div id="responder${j}" class="panel-collapse collapse">
		                           				<div class="panel-body">
		                           					<textarea name="ta2-${pubNivel2._id}" style="width:100%"></textarea>
		                           					<button class="btn btn-default confirmar-responder" name="${pubNivel2._id}">Confirmar respuesta</button>
		                           				</div>
		                           			</div>
		                            	</div>
	                           	`
	                           
				pubNivel2.publicaciones.forEach((pubNivel3,k) => {
					seccionPubs += `
						<div class="panel-group" id="accordion${i}-${j}-${k}">
	                        <div class="panel panel-default panel-red">
	                            <div class="panel-heading">
	                                <h4 class="panel-title">
	                                    <a data-toggle="collapse" data-parent="#accordion${i}-${j}-${k}" href="#collapse${i}-${j}-${k}">${pubNivel3.fecha}</a>
	                                </h4>
	                            </div>
	                            <div id="collapse${i}-${j}-${k}" class="panel-collapse collapse in">
	                                <div class="panel-body">
	                                    ${pubNivel3.contenido}
	                                </div>
	                            </div>
	                        </div>
	                    </div>
					 `
				});

				seccionPubs += `
								</div>
	                        </div>
	                    </div>
	                </div>
	            </div>
				`
			});

			seccionPubs+=`
							</div>
		                </div>
		            </div>
		        </div>
		    </div>
			 `;
		});
		$("#pubs").html(seccionPubs);

		$(".confirmar-comentar").click((event)=>{
			const idPublicacionAComentar = event.target.name;
			const contenidoNuevoComentario = $(`[name=ta-${idPublicacionAComentar}]`).val().trim();

			if(contenidoNuevoComentario !== ""){
				$.ajax({
				    url: 'http://localhost:8085/crearpublicacion',
				    type: 'post',
				    data: {
				        contenido  : contenidoNuevoComentario,
				        publicacion: idPublicacionAComentar
				    },
				    headers: {
				        "Authorization": localStorage.getItem("red_social_token")  
				    },
				    dataType: 'json',
				    success: function (data) {
				        location.reload();
				    }
				});
			}
		});

		$(".confirmar-responder").click((event)=>{
			const idPublicacionAResponder = event.target.name;
			const contenidoNuevaRespuesta = $(`[name=ta2-${idPublicacionAResponder}]`).val().trim();

			if(contenidoNuevaRespuesta !== ""){
				$.ajax({
				    url: 'http://localhost:8085/crearpublicacion',
				    type: 'post',
				    data: {
				        contenido  : contenidoNuevaRespuesta,
				        publicacion: idPublicacionAResponder
				    },
				    headers: {
				        "Authorization": localStorage.getItem("red_social_token")  
				    },
				    dataType: 'json',
				    success: function (data) {
				        location.reload();
				    }
				});
			}
		});
    }
});