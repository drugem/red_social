'use strict';

//Implementación de api gateway para conexión con microservicios

//Importación de módulos de 3ros
import fetch from 'node-fetch';
import fs from 'fs';

//Lecutra de archivo config
const config = JSON.parse(fs.readFileSync("config.json", "utf8"));
const gestionUsuariosServer = config.gestionUsuarioServer;
const publicacionesServer   = config.publicacionesServer;
const mensajeriaServer      = config.mensajeriaServer;

var apigateway = {};
const jsonContentType =  {'Content-Type': 'application/json'};

//Funciones ping
apigateway.pingUsuarios = async function(){
	try{
		const pingUsuarios = await fetch(`http://${gestionUsuariosServer}/ping`);
		const bodyPongUsuarios = await pingUsuarios.text();
		if(bodyPongUsuarios !== "pong"){
			console.log("No ha sido posible conectar a servidor de gestión de usuarios: servidor no ha retornado una respuesta esperada");
			return false;
		}
		return true;
	}catch(exPingUsuarios){
		console.log(`No ha sido posible conectar al servidor de gestión de usuarios: servidor no ha retornado una respuesta\n${exPingUsuarios}`);
		return false;
	}
}

apigateway.pingPublicaciones = async function (){
	try{
		const pingPublicaciones = await fetch(`http://${publicacionesServer}/ping`);
		const bodyPongPublicaciones = await pingPublicaciones.text();
		if(bodyPongPublicaciones !== "pong"){
			console.log("No ha sido posible conectar a servidor de publicaciones: servidor no ha retornado una respuesta esperada");
			return false;
		}
		return true;
	}catch(exPingPublicaciones){
		console.log(`No ha sido posible conectar al servidor de publicaciones: servidor no ha retornado una respuesta\n${exPingPublicaciones}`);
		return false;
	}
}

apigateway.pingMensajeria = async function (){
	try{
		const pingMensajeria = await fetch(`http://${mensajeriaServer}/ping`);
		const bodyPongMensajeria = await pingMensajeria.text();
		if(bodyPongMensajeria !== "pong"){
			console.log("No ha sido posible conectar a servidor de mensajería: servidor no ha retornado una respuesta esperada");
			return false;
		}
		return true;
	}catch(exPingMensajeria){
		console.log(`No ha sido posible conectar al servidor de mensajería: servidor no ha retornado una respuesta\n${exPingMensajeria}`);
		return false;
	}
}

//Funciones para usar el miscroservicio de usuarios
apigateway.validarCreds = async function(nombreValidarCred, pwdValidarCred){
	return new Promise(async(resolve,reject) => {
		try{
			const usuarioValidar = {
				nombre: nombreValidarCred,
				pwd   : pwdValidarCred
			}
			const responseValidarCreds = await fetch(`http://${gestionUsuariosServer}/validarcreds`, {method: 'POST', body: JSON.stringify(usuarioValidar), headers: jsonContentType});
			const validacionUsuario = await responseValidarCreds.text();
			resolve(validacionUsuario);
		}catch(exValidarCreds){
			console.log(`No ha sido posible validar credenciales:\n${exValidarCreds}`);
			reject(exValidarCreds);
		}
	});
}

apigateway.getUsuarioPorId = async function(idUsuario){
	return new Promise(async(resolve,reject) => {
		try{
			const idBuscar = {
				_id: idUsuario
			}
			const responseUsuarioPorId = await fetch(`http://${gestionUsuariosServer}/getusuarioporid`, {method: 'POST', body: JSON.stringify(idBuscar), headers: jsonContentType});
			const usuarioEncontradoId = await responseUsuarioPorId.json();
			resolve(usuarioEncontradoId);
		}catch(exBuscarUsuarioId){
			console.log(`No ha sido posible encontrar el usuario de id ${idUsuario}:\n${exBuscarUsuarioId}`);
			reject(exBuscarUsuarioId);
		}
	});
}

//Encontrar personas cuyo nombre contiene ${nombreContiene}
apigateway.personasNombreContiene = function(nombreContiene){
	return new Promise(async (resolve,reject) => {
		const body = {
			contiene: nombreContiene
		}
		try{
			const responseNombreContiene = await fetch(`http://${gestionUsuariosServer}/nombrecontiene`, {method: 'POST', body: JSON.stringify(body), headers: jsonContentType});
			const usuariosNombreContiene = await responseNombreContiene.json();
			resolve(usuariosNombreContiene);	
		}catch(exNombreContiene){
			console.log(`No ha sido posible encontrar usuarios que contengan "${nombreContiene}":\n${exNombreContiene}`);
			reject(exNombreContiene);
		}
	});
}

//Funciones para usar el microservicio de publicaciones
apigateway.crearPublicacion = function(nuevaPublicacion){
	return new Promise(async (resolve,reject) => {
		const body = {
			contenido:   nuevaPublicacion.contenido,
			usuario:     nuevaPublicacion.usuario,
			publicacion: nuevaPublicacion.publicacion
		}
		try{
			const responseNuevaPublicacion = await fetch(`http://${publicacionesServer}/publicar`, {method: 'POST', body: JSON.stringify(body), headers: jsonContentType});
			const resultadoCreacionPublicacion = await responseNuevaPublicacion.json();
			resolve(resultadoCreacionPublicacion);	
		}catch(exCreacionPublicacion){
			console.log(`No ha sido posible crear publicación:\n${exCreacionPublicacion}`);
			reject(exCreacionPublicacion);
		}
	});
}

apigateway.publicacionesDeUsuario = function(idUsuarioPublicaciones){
	return new Promise(async (resolve,reject) => {
		const body = {
			_id: idUsuarioPublicaciones
		}
		try{
			const responsePublicacionesUsuario = await fetch(`http://${publicacionesServer}/getpublicacionesusuario`, {method: 'POST', body: JSON.stringify(body), headers: jsonContentType});
			const publicacionesUsuario = await responsePublicacionesUsuario.json();
			resolve(publicacionesUsuario);	
		}catch(exPublicacionesUsuario){
			console.log(`No ha sido posible encontrar las publicaciones del usuario "${idUsuarioPublicaciones}":\n${exPublicacionesUsuario}`);
			reject(exPublicacionesUsuario);
		}
	});
}

apigateway.getPublicacionPorId = function(idPublicacion){
	return new Promise(async (resolve,reject) => {
		const body = {
			_id: idPublicacion
		}
		try{
			const responsePublicacionPorId = await fetch(`http://${publicacionesServer}/getpublicacionporid`, {method: 'POST', body: JSON.stringify(body), headers: jsonContentType});
			const publicacionPorId = await responsePublicacionPorId.json();
			resolve(publicacionPorId);	
		}catch(exGetPublicacionPorId){
			console.log(`No ha sido posible encontrar la publicación "${idPublicacion}":\n${exGetPublicacionPorId}`);
			reject(exGetPublicacionPorId);
		}
	});
}

//Funciones para usar el miscroservicio de mensajería
apigateway.enviarCorreo = function(para, asunto, cuerpo){
	
	return new Promise(async (resolve,reject) => {
		const body = {
			para: para,
			asunto: asunto,
			cuerpo: cuerpo
		}
		try{
			const responseEnvioCorreo = await fetch(`http://${mensajeriaServer}/enviarcorreo`, {method: 'POST', body: JSON.stringify(body), headers: jsonContentType});
			const isCorreoEnviado = await responseEnvioCorreo.json();
			resolve(isCorreoEnviado);	
		}catch(exEnvioCorreo){
			console.log(`No ha sido posible enviar correo a "${para}":\n${exEnvioCorreo}`);
			reject(exEnvioCorreo);
		}
	});
}

export default apigateway;