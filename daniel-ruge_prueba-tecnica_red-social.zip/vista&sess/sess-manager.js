'use strict';

//Implementación de manejo de sesiones y autenticación con JWT

//Importación de módulos de 3ros
import jwt from 'jsonwebtoken';
import rndStr from 'randomstring';

var sess_mgr = {};

//Arreglo para almacenar las sesiones autenticadas
sess_mgr.sesiones = [];

//Funciones para la administraciones de sesiones autenticadas

sess_mgr.generarToken = function(contenidoToken){
	const key = rndStr.generate(10);
	const token = jwt.sign({_id:contenidoToken}, key, { expiresIn: 3600 });

	sess_mgr.sesiones.push({
		token:   token,
		key:     key
	});

	return token;
}

sess_mgr.verificarToken = function(tokenVerificar){
	var sesion;
	var decodificacion;
	var resultadoVerificacion = {
		valido   : false,
		payload: null,
		vencida  : null
	};
	for(var i=0; i<sess_mgr.sesiones.length; i++){
		sesion = sess_mgr.sesiones[i];
		try{
			decodificacion = jwt.verify(tokenVerificar, sesion.key);
			resultadoVerificacion.valido = true;
			resultadoVerificacion.payload = decodificacion;
			resultadoVerificacion.vencida = false;
			break;
		}catch(exDecodificacion){
			if(exDecodificacion.message === "jwt expired"){
				resultadoVerificacion.vencida = true;

				//Eliminar del arreglo
				sess_mgr.sesiones.splice(i, 1);
				break;
			}
			else{
				if(exDecodificacion.message !== "invalid signature"){
					throw "No es posible decodificar tokens!";
				}
			}
			
		}
	}
	return resultadoVerificacion;
}

//TODO: el arreglo sess_mgr.sesiones debe tener mantenimiento: sesiones que lleven mucho tiempo vencidas, deben borrarse automáticamente

export default sess_mgr;