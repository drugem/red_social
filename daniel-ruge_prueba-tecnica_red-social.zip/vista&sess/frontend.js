'use strict';

//Importación de módulos de 3ros
import express from 'express';
import fetch from 'node-fetch';
import ip from 'ip';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

//Importación de módulos implementados
import apigateway from './apigateway.js';
import sessMgr from './sess-manager.js';

//Lecutra de archivo config
const config = JSON.parse(fs.readFileSync("config.json", "utf8"));
const gestionUsuariosServer = config.gestionUsuarioServer;
const publicacionesServer   = config.gestionUsuarioServer;
const mensajeriaServer      = config.gestionUsuarioServer;

//Declaración de __dirname para referenciar archivos html
const __dirname = path.dirname(fileURLToPath(import.meta.url))+"/public/";

//Primero, hacer un ping a cada servidor (microservicio) para ver si están online. Si sí, iniciar servidor web (frontend)---------------------------------------------------------------
//Usuarios

if(apigateway.pingUsuarios()){
	console.log("Servidor de usuarios conectado con éxito");
	if(apigateway.pingPublicaciones()){
		console.log("Servidor de publicaciones conectado con éxito");
		if(apigateway.pingMensajeria()){
			console.log("Servidor de mensajería conectado con éxito");
		}
		else{
			process.exit();
		}
	}
	else{
		process.exit();
	}
}
else{
	process.exit();
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//Iniciar servidor
const frontendServer = express();
frontendServer.use(express.json());
frontendServer.use(express.urlencoded({extended: true}));
frontendServer.use(express.static(__dirname));

frontendServer.listen(8085, async function(){
	console.log("Servidor frontend iniciado: "+ip.address()+":8085");
});

//Definición de endpoints para invocación de servicios REST

frontendServer.get("*",function(request,result){
	const validacionToken = verificarToken(request);
	if(validacionToken && validacionToken.validez){
		result.sendFilee(__dirname+"inicio.html");
	}
	else{
		result.sendFile(__dirname+"login.html");
	}
});

frontendServer.post("/login", async function(request,result){
	const nombreLogin = request.body.nombre;
	const pwdLogin = request.body.pwd;
	const idUsuario = await apigateway.validarCreds(nombreLogin, pwdLogin);
	if(idUsuario == false){
		const tokenLogin = sessMgr.generarToken(idUsuario);

		//Aquí se escribirá una nueva página web dinámicamente que lo único que hace es settear en el
		//localstorage el token recién generado y luego redirigir a la página principal
		const clientSideTokenSetter = `<script>localStorage.setItem('red_social_token', '${tokenLogin}');window.location.href = "inicio.html";</script>`
		const nombreArchivoTempSetToken = `${tokenLogin}.html`;
		const pathArchivoTempSetToken = `public/tmp/${nombreArchivoTempSetToken}`
		const archivoTempSetToken = fs.writeFileSync(pathArchivoTempSetToken, clientSideTokenSetter, "utf8");
		result.sendFile(__dirname+"tmp/"+nombreArchivoTempSetToken);
	}else{
		result.sendFile(__dirname+"login.html");
	}
});

frontendServer.post("/encontrarpersonasnombre", async function(request,result){
	const verifToken = verificarToken(request);
	if(!verifToken.validez){
		result.sendFile(__dirname+"login.html");
	}
	else{
		let usuariosNombreContiene;
		try{
			usuariosNombreContiene = await apigateway.personasNombreContiene(request.body.nombre);
			result.send(usuariosNombreContiene);
		}catch(exUsuariosNombreContiene){
			console.log(`No ha sido posible buscar usuarios cuyo nombre contiene ${usuariosNombreContiene}:${exUsuariosNombreContiene}`);
			result.status(500).send({
				message: exUsuariosNombreContiene.toString()
			});
		}
	}
});

frontendServer.post("/getpublusuario", async function(request,result){
	const verifToken = verificarToken(request);
	if(!verifToken.validez){
		result.sendFile(__dirname+"login.html");
	}
	else{
		let publicacionesUsuario;
		try{
			publicacionesUsuario = await apigateway.publicacionesDeUsuario(request.body._id);
			result.send(publicacionesUsuario);	
		}catch(exGetPublUsuario){
			console.log(`No ha sido posible buscar las publicaciones del usuario ${request.body._id}:${exGetPublUsuario}`);
			result.status(500).send({
				message: exGetPublUsuario.toString()
			});
		}
	}
});

frontendServer.post("/crearpublicacion", async function(request,result){
	const verifToken = verificarToken(request);
	if(!verifToken.validez){
		result.sendFile(__dirname+"login.html");
	}
	else{
		const infoCreacionPublicacion = request.body;
		infoCreacionPublicacion.usuario = verifToken.contenido.payload._id;
		try{
			const resultadoCreaPublicacion = await apigateway.crearPublicacion(infoCreacionPublicacion);
			result.send(resultadoCreaPublicacion);

			//Ahora, enviar correo a dueño de publicación
			//Primero, conocer el dueño de la publicación sobre la que se está comentando (si es que és una respuesta a una publicación)
			if(infoCreacionPublicacion.publicacion){
				const infoPublicacionComentada = await apigateway.getPublicacionPorId(infoCreacionPublicacion.publicacion);
				const usuarioOwner = await apigateway.getUsuarioPorId(infoPublicacionComentada.usuario);
				const correoEnviado = await apigateway.enviarCorreo(usuarioOwner.correo,"Red social es muy social","Has recibido un comentario en una publicación!");
			}
		}catch(exCreaPublicacion){
			console.log(`No ha sido posible crear publicación:${exCreaPublicacion}`);
			result.status(500).send({
				message: exCreaPublicacion.toString()
			});
		}
	}
});

frontendServer.get("/getpublicacionesusuarioauth", async function(request,result){
	const verifToken = verificarToken(request);
	if(!verifToken.validez){
		result.sendFile(__dirname+"login.html");
	}
	else{
		let publicacionesUsuario;
		try{
			publicacionesUsuario = await apigateway.publicacionesDeUsuario(verifToken.contenido.payload._id);
			result.send(publicacionesUsuario);	
		}catch(exGetPublUsuario){
			console.log(`No ha sido posible buscar las publicaciones del usuario ${verifToken.contenido.payload._id}:${exGetPublUsuario}`);
			result.status(500).send({
				message: exGetPublUsuario.toString()
			});
		}
	}
});

//Función para validar encapsular uso de sess-mgr
function verificarToken(request){
	const headerAuth = request.get("Authorization");
	if(!headerAuth){
		return;
	}

	const token = headerAuth.replace("Bearer ", "");
	const verificacionToken = sessMgr.verificarToken(token);
	var retorno = {
		contenido: verificacionToken,
		validez: undefined
	}
	if(verificacionToken.valido){
		retorno.validez = true;
	}
	else{
		if(verificacionToken.vencida){
			retorno.validez = false;
		}
	}

	return retorno;
}